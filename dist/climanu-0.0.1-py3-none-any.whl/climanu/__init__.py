from climanu.climanu import SimpleManu
from climanu.climanu import TableManu
